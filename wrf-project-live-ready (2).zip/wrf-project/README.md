# World Revealed Fact (WRF) — Foundation Starter

**Tagline:** Reveal the World. Verify the Facts.

This starter contains a React/Vite public-site foundation (home, country atlas/search, WRF standard, comparison placeholder, map placeholder, data catalogue placeholder, and sources/evidence principles) plus a Supabase SQL migration. It is not a deployed website and does not include real country data. Comparison, map, and catalogue areas are honest placeholders until their real data workflows are implemented.

## Local setup

1. Install Node.js 20+ and npm.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your Supabase project URL and publishable/anon key to `.env.local`. Never put a `service_role` key in the browser app.
5. In a **development** Supabase project, review and run `supabase/migrations/202610110001_wrf_foundation.sql` in the SQL Editor.
6. Run `npm run test:security`, `npm run typecheck`, and `npm run build`. The current security tests inspect migration source text; they do not execute SQL against PostgreSQL or replace live RLS/integration tests.
7. Run `npm run dev` to open the local preview.

## Security notes

- RLS is enabled for all WRF tables.
- Anonymous access is read-only and published facts are the only values exposed by the public policy.
- Client users cannot assign roles to themselves. Founder bootstrap is intentionally not implemented as a public signup flow; provision the first Founder through a separately authenticated trusted-operator process.
- Review decisions must use `wrf_review_value(...)`; direct authenticated updates/deletes on values are revoked. The RPC requires a reviewer role, blocks self-review, and requires an approved source before publication.
- Do not deploy until the SQL migration is reviewed and executed, the Founder provisioning procedure is implemented and verified, and all tests pass against a development project.

## Current limits

The country atlas stays empty until verified country records are loaded. This starter does not claim live Supabase connectivity, deployment, production readiness, or a completed Founder/Admin UI.

## Hosting preparation (database not required for a visual preview)

- Vercel configuration is included in `vercel.json`; import this project repository into Vercel and keep the root directory at the folder containing `package.json`.
- Netlify configuration is included in `netlify.toml`; set the publish directory to `dist` (already configured).
- Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` only when ready to connect the development Supabase project. These are public client configuration values; never add a Supabase `service_role` key to Vite variables.
- Add a canonical URL using the actual production domain before launch; it is intentionally omitted until the domain is known.
- A public preview can show the landing page without a database, but country data, Founder/Admin/Reviewer workflows, and real evidence review are not live until their backend and permissions are implemented and verified. Do not describe the current preview as production-ready.
